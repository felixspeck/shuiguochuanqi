package com.external.alipay;

public class Constant
{
	public final static String server_url = "https://msp.alipay.com/x.htm";
}