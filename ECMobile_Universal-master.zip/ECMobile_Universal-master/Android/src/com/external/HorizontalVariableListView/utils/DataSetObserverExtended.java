package com.external.HorizontalVariableListView.utils;

import android.database.DataSetObserver;

public abstract class DataSetObserverExtended extends DataSetObserver {

	public void onAdded() {
		// Do Nothing
	}

	public void onRemoved() {
		// Do Nothing
	}
}
