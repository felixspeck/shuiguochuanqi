/** Automatically generated file. DO NOT MODIFY */
package com.alipay.android.app.sdk;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}