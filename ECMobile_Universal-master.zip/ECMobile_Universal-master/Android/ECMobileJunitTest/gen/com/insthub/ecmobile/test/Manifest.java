/*___Generated_by_IDEA___*/

package com.insthub.ecmobile.test;

/* This stub is only used by the IDE. It is NOT the Manifest class actually packed into the APK */
public final class Manifest {
}